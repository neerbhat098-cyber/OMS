const s = window.supabaseClient;

// ================= ROUTER =================
window.onload = function(){
    loadPage("dashboard");
};

function loadPage(page){

    if(page === "dashboard"){
        document.getElementById("pageContent").innerHTML = dashboardUI();
        loadDashboardData();
    }

    if(page === "orders"){
        document.getElementById("pageContent").innerHTML = ordersUI();
        loadOrders();
    }

    if(page === "dealers"){
        document.getElementById("pageContent").innerHTML = "<div class='section'>Dealers Page</div>";
    }

    if(page === "users"){
        document.getElementById("pageContent").innerHTML = "<div class='section'>Users Page</div>";
    }
}

// ================= DASHBOARD UI =================
function dashboardUI(){
return `
<div class="header">
    <h3>Welcome Admin</h3>
</div>

<div class="kpi">

    <div class="card">
        <h3>Users</h3>
        <h1 id="usersCount">0</h1>
    </div>

    <div class="card">
        <h3>Dealers</h3>
        <h1 id="dealersCount">0</h1>
    </div>

    <div class="card">
        <h3>Orders</h3>
        <h1 id="ordersCount">0</h1>
    </div>

    <div class="card">
        <h3>Sales</h3>
        <h1 id="salesAmount">0</h1>
    </div>

</div>
`;
}

// ================= ORDERS UI =================
function ordersUI(){
return `
<div class="section">
    <h3>Orders</h3>

    <table>
        <thead>
            <tr>
                <th>Order No</th>
                <th>Dealer</th>
                <th>Amount</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody id="ordersTable"></tbody>
    </table>
</div>
`;
}

// ================= LOAD DASHBOARD DATA =================
async function loadDashboardData(){

    const { count: users } = await s.from("users").select("*",{count:"exact",head:true});
    const { count: dealers } = await s.from("dealers").select("*",{count:"exact",head:true});
    const { count: orders } = await s.from("orders").select("*",{count:"exact",head:true});

    const { data: items } = await s.from("order_items").select("amount");

    let sales = 0;
    (items || []).forEach(i=>{
        sales += Number(i.amount || 0);
    });

    document.getElementById("usersCount").innerText = users || 0;
    document.getElementById("dealersCount").innerText = dealers || 0;
    document.getElementById("ordersCount").innerText = orders || 0;
    document.getElementById("salesAmount").innerText = sales || 0;
}

// ================= LOAD ORDERS =================
async function loadOrders(){

    const { data } = await s.from("orders").select("*");

    let html = "";

    (data || []).forEach(o=>{
        html += `
        <tr>
            <td>${o.order_no || "-"}</td>
            <td>${o.dealer_id}</td>
            <td>${o.total_amount}</td>
            <td>${o.status}</td>
        </tr>
        `;
    });

    document.getElementById("ordersTable").innerHTML = html;
}

// ================= LOGOUT =================
async function logout(){
    localStorage.removeItem("oms_user");
    await s.auth.signOut();
    window.location.href = "login.html";
}