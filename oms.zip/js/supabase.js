const SUPABASE_URL = "https://opaesbbawyzegoawnlaz.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_6BikaemYS93iFw8b1tezjw_LG2G1rgN";

const supabaseClient = supabase.createClient(
    SUPABASE_URL,
    SUPABASE_ANON_KEY
);
let currentUser = JSON.parse(localStorage.getItem("user"));