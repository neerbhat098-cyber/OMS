
// ===============================
// SUPABASE CLIENT
// ===============================
const supabaseClient = supabase.createClient(
    "https://opaesbbawyzegoawnlaz.supabase.co",
    "sb_publishable_6BikaemYS93iFw8b1tezjw_LG2G1rgN"
);

// make global for dashboard
window.supabaseClient = supabaseClient;


// ===============================
// LOGIN FUNCTION (FULL)
// ===============================
async function loginUser() {

    const email = document.getElementById("email").value
        .trim()
        .toLowerCase();

    const password = document.getElementById("password").value;

    const loader = document.getElementById("loading");
    if (loader) loader.style.display = "flex";

    try {

        // STEP 1: AUTH LOGIN
        const { data, error } =
            await supabaseClient.auth.signInWithPassword({
                email,
                password
            });

        if (error) throw error;

        // STEP 2: FETCH USER PROFILE
        const { data: profile, error: profileError } =
            await supabaseClient
                .from("users")
                .select("email, role, status, full_name")
                .eq("email", email)
                .single();

        if (profileError || !profile) {
            throw new Error("User not found in users table");
        }

        // STEP 3: NORMALIZE DATA
        const role = (profile.role || "").toLowerCase().trim();
        const status = (profile.status || "").toLowerCase().trim();

        if (status !== "active") {
            throw new Error("Account is inactive");
        }

        // STEP 4: SAVE SESSION
        localStorage.setItem("oms_user", JSON.stringify({
            email: email,
            role: role,
            name: profile.full_name
        }));

        // STEP 5: LOADING DELAY
        await new Promise(r => setTimeout(r, 800));

        if (loader) loader.style.display = "none";

        // STEP 6: ROLE REDIRECT
        if (profile.role === "Admin") {
            window.location.href = "dashboard.html";
        }
        else if (profile.role === "sales") {
            window.location.href = "sales/salesdashboard.html";
        }
        else {
            alert("Invalid role: " + profile.role);
        }

    } catch (err) {

        if (loader) loader.style.display = "none";

        console.error(err);
        alert(err.message);
    }
}


// ===============================
// GET CURRENT USER
// ===============================
function getCurrentUser() {
    return JSON.parse(localStorage.getItem("oms_user") || "null");
}


// ===============================
// AUTH CHECK
// ===============================
function requireAuth() {

    const user = getCurrentUser();

    if (!user) {
        window.location.href = "login.html";
        return null;
    }

    return user;
}


// ===============================
// ROLE CHECK
// ===============================
function isAdmin() {

    const user = getCurrentUser();
    return user?.role === "Admin";
}


// ===============================
// LOGOUT
// ===============================
async function logout() {

    localStorage.removeItem("oms_user");

    await supabaseClient.auth.signOut();

    window.location.href = "login.html";
}


// ===============================
// LOADING CONTROL
// ===============================
function showLoading(state) {

    const loader = document.getElementById("loading");

    if (!loader) return;

    loader.style.display = state ? "flex" : "none";
}