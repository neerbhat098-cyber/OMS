
// LOAD DEALERS
async function loadDealers() {

    console.log("Dealer loading started");

    let { data, error } = await supabaseClient
        .from("dealers")
        .select("*");

    console.log("DATA:", data);
    console.log("ERROR:", error);

    let table = document.querySelector("#dealerTable tbody");

    if(error) {
        alert("ERROR: " + error.message);
        return;
    }

    if(!data || data.length === 0) {
        table.innerHTML = "<tr><td colspan='4'>No dealers found</td></tr>";
        return;
    }

    table.innerHTML = "";

    data.forEach(d => {

        table.innerHTML += `
        <tr>
            <td>${d.dealer_code}</td>
            <td>${d.dealer_name}</td>
            <td>${d.address}</td>
            <td>${d.mobile}</td>
        </tr>
        `;
    });
}


// ADD DEALER
async function addDealer() {

    let dealer = {
        dealer_code: document.getElementById("dealer_code").value,
        dealer_name: document.getElementById("dealer_name").value,
        address: document.getElementById("address").value,
        mobile: document.getElementById("mobile").value
    };

    await supabaseClient
        .from("dealers")
        .insert([dealer]);

    alert("Dealer Added");

    loadDealers();
}


// SEARCH
function filterDealers() {

    let input = document.getElementById("searchBox").value.toLowerCase();

    let rows = document.querySelectorAll("#dealerTable tbody tr");

    rows.forEach(row => {

        row.style.display =
            row.innerText.toLowerCase().includes(input)
            ? "" : "none";
    });
}


// INIT
loadDealers();