let orderItems = [];

async function loadDealers() {

    let { data } = await supabaseClient
        .from("dealers")
        .select("*");

    let select = document.getElementById("dealerSelect");

    select.innerHTML = `<option value="">Select Dealer</option>`;

    data.forEach(d => {

        select.innerHTML += `
            <option value="${d.id}">
                ${d.dealer_name}
            </option>
        `;
    });
}
async function searchProducts() {

    let keyword =
        document.getElementById("searchProduct").value;

    if(keyword.length < 2) {
        document.getElementById("searchResults").innerHTML = "";
        return;
    }

    let { data } = await supabaseClient
        .from("products")
        .select("*")
        .ilike("product_name", `%${keyword}%`);

    let box = document.getElementById("searchResults");

    box.innerHTML = "";

    data.forEach(p => {

        box.innerHTML += `
        <div onclick='addProduct(${JSON.stringify(p)})'
             style="padding:10px;cursor:pointer;border:1px solid #ddd;margin:5px;">
            ${p.product_name} - ₹${p.rate}
        </div>
        `;
    });
}

function addProduct(product) {

    let item = {
        product_id: product.id,
        product_name: product.product_name,
        rate: product.rate,
        qty: 1,
        amount: product.rate
    };

    orderItems.push(item);

    renderTable();
}

function renderTable() {

    let tbody = document.querySelector("#orderTable tbody");

    tbody.innerHTML = "";

    let total = 0;

    orderItems.forEach((item, index) => {

        total += item.amount;

        tbody.innerHTML += `
        <tr>
            <td>${item.product_name}</td>
            <td>${item.rate}</td>
            <td>
                <input type="number" value="${item.qty}"
                onchange="updateQty(${index}, this.value)">
            </td>
            <td>${item.amount}</td>
            <td>
                <button onclick="removeItem(${index})">X</button>
            </td>
        </tr>
        `;
    });

    document.getElementById("totalAmount").innerText = total;
}

function updateQty(index, qty) {

    orderItems[index].qty = qty;
    orderItems[index].amount =
        orderItems[index].rate * qty;

    renderTable();
}

function removeItem(index) {

    orderItems.splice(index, 1);

    renderTable();
}

async function submitOrder() {

    let dealerId =
        document.getElementById("dealerSelect").value;

    if(!dealerId || orderItems.length === 0) {
        alert("Select dealer and add products");
        return;
    }

    // 1. Insert Order
    let { data: order } = await supabaseClient
        .from("orders")
        .insert([{
            dealer_id: dealerId,
            total_amount: orderItems.reduce((a,b)=>a+b.amount,0),
            status: "Pending"
        }])
        .select()
        .single();

    // 2. Insert Order Items
    let items = orderItems.map(i => ({
        order_id: order.id,
        product_id: i.product_id,
        qty: i.qty,
        rate: i.rate,
        amount: i.amount
    }));

    await supabaseClient
        .from("order_items")
        .insert(items);

    alert("Order Created Successfully");

    orderItems = [];
    renderTable();
}

loadDealers();