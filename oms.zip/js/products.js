
// LOAD PRODUCTS
async function loadProducts() {

    let { data, error } =
        await supabaseClient
        .from("products")
        .select("*")
        .order("created_at", { ascending: false });

    let table = document.querySelector("#productTable tbody");
    table.innerHTML = "";

    data.forEach(p => {

        table.innerHTML += `
        <tr>
            <td>${p.product_code}</td>
            <td>${p.product_name}</td>
            <td>${p.category}</td>
            <td>${p.mrp}</td>
            <td>${p.rate}</td>
            <td>${p.net_rate}</td>
        </tr>
        `;
    });
}




// SEARCH FILTER
function filterProducts() {

    let input = document.getElementById("searchBox").value.toLowerCase();

    let rows = document.querySelectorAll("#productTable tbody tr");

    rows.forEach(row => {

        let text = row.innerText.toLowerCase();

        row.style.display =
            text.includes(input) ? "" : "none";
    });
}


// INIT
loadProducts();

async function uploadFile() {

    let file = document.getElementById("fileInput").files[0];

    let reader = new FileReader();

    reader.onload = async function(e) {

        let data = new Uint8Array(e.target.result);

        let workbook = XLSX.read(data, { type: "array" });

        let sheet = workbook.Sheets[workbook.SheetNames[0]];

        let json = XLSX.utils.sheet_to_json(sheet);

        for (let item of json) {

            await supabaseClient
                .from("products")
                .upsert([item], {
                    onConflict: "product_code"
                });
        }

        alert("Upload Completed");
        loadProducts();
    };

    reader.readAsArrayBuffer(file);
}